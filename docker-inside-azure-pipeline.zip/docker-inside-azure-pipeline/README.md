
# Docker Inside Azure Pipeline
Web App with old technology deployed in docker with x86/x64 constrain and executed from azure pipeline

## Azure Pipeline

## Docker Multistage
Docker multistage example for build and deploy the Web App, these docker images only work in x86 or x64

## Example Web App
Scala Play framework web backend application (Scala 2.12.8) and an old React 18.2.0 frontend application (node 8.17.0)
