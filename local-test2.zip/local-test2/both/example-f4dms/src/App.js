import React from 'react';
import './App.css';
import { MyComponent } from './MyComponent';

function App() {
  return (
    <MyComponent></MyComponent>
  );
}

export default App;
